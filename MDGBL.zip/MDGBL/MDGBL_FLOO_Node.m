% =========================================================================
function best_rmse = MDGBL_FLOO_Node(Xtrain_S1, Xtrain_S2, ...
    node1_min, node1_max, node1_step, ...
    node2_min, node2_max, node2_step, ...
    node3_min, node3_max, node3_step)

rng(0, 'twister');
%%------------------------1. Calculation of Input for Related Parameters------------------------------
% Calculate the number of search steps for parameters
ND1 = (node1_max - node1_min) / node1_step + 1;  
ND2 = (node2_max - node2_min) / node2_step + 1; 
ND3 = (node3_max - node3_min) / node3_step + 1;  

% Generate parameter search space
param_node1 = linspace(node1_min, node1_max, ND1);  
param_node2 = linspace(node2_min, node2_max, ND2);  
param_node3 = linspace(node3_min, node3_max, ND3);  

% Candidate values of penalty parameters
Gamma = [0.1, 0.3, 0.5, 0.7, 0.9];    
Lamda = [0.1, 0.3, 0.5, 0.7, 0.9];    

%%------------------------2. Loading of Training Dataset------------------------------------
% Source domain 1: Split labels and features
YX1 = Xtrain_S1(:, 1);               
X1 = Xtrain_S1(:, 2:end);             
Number1 = size(Xtrain_S1, 1);         

% Source domain 2: Split labels and features
YX2 = Xtrain_S2(:, 1);               
X2 = Xtrain_S2(:, 2:end);             
Number2 = size(Xtrain_S2, 1);         

% Merge labels of dual source domains
YX = [YX1; YX2];                      
Number = Number1 + Number2;         

% Initialize optimal RMSE
best_rmse = 70;

% Output initialization information
disp('MDGBL_FLOO dual-source domain parameter optimization started');
disp('Starting fast leave-one-out (FLOO) parameter selection......');

%%------------------------3. Establish FLOO-CV Parameter Optimization Model-----------------------------
disp('Optimizing the number of neurons for the dual-source domain model.....');

% Loop 1: Number of feature nodes per group
for t1 = 1:ND1
    current_node1 = param_node1(t1);
    disp(['\nSelecting the number of feature nodes per group..... Round: ', num2str(t1), '/', num2str(ND1), ', Current value: ', num2str(current_node1)]);

    % Loop 2: Number of feature node groups
    for t2 = 1:ND2
        current_node2 = param_node2(t2);
        disp(['Selecting the number of feature node groups..... Group: ', num2str(t2), '/', num2str(ND2), ', Current value: ', num2str(current_node2)]);

        % Loop 3: Number of enhancement nodes
        for t3 = 1:ND3
            current_node3 = param_node3(t3);
            disp(['Selecting the number of enhancement nodes..... Iteration: ', num2str(t3), '/', num2str(ND3), ', Current value: ', num2str(current_node3)]);

            % Calculate hidden layer output matrices of dual source domains
            [H_S1, H_S2, InputWeight, InputWeight1, wh, WF1] = ...
                MDGBL_FLOO(X1, X2, current_node1, current_node2, current_node3);

            % Loop 4: Penalty parameter Lamda
            disp('Selecting the penalty parameter Lamda.....');
            for k = 1:length(Lamda)
                current_lamda = Lamda(k);

                % Loop 5: Penalty parameter Gamma
                disp('Selecting the penalty parameter Gamma.....');
                for i = 1:length(Gamma)
                    current_gamma = Gamma(i);

                    % Calculate pseudoinverse matrix
                    if current_node1 * current_node2 <= Number1
                        % Case 1: Sufficient samples in source domain 1
                        H_mat = eye(size(H_S1'*H_S1)) + current_lamda*(H_S1'*H_S1) + current_gamma*(H_S2'*H_S2);
                        pin_H_S1 = current_lamda * pinv(H_mat) * H_S1';
                        pin_H_S2 = current_gamma * pinv(H_mat) * H_S2';
                    else
                        % Case 2: Insufficient samples in source domain 1
                        A = H_S2 * H_S1';
                        B = H_S2 * H_S2' + eye(size(H_S2*H_S2'))/current_gamma;
                        C = H_S1 * H_S2';
                        D = H_S1 * H_S1' + eye(size(H_S1*H_S1'))/current_lamda;

                        pin_H_S1 = (H_S2'*pinv(B)*A - H_S1') * pinv(H_S1*H_S2'*pinv(B)*A - D);
                        pin_H_S2 = H_S2'*pinv(B) + ...
                            H_S1'*pinv(C*pinv(B)*A - D)*C*pinv(B) - ...
                            H_S2'*pinv(B)*A*pinv(C*pinv(B)*A - D)*C*pinv(B);
                    end

                    % Fast leave-one-out validation
                    P_yi = zeros(Number, 1);  
                    ri = zeros(Number, 1);    

                    for j = 1:Number
                        yi = YX(j);

                        % Match hidden layer output of current sample
                        if j <= Number1
                            Hi = H_S1(j, :);  % Sample from source domain 1
                        else
                            Hi = H_S2(j - Number1, :);  % Sample from source domain 2
                        end

                        % Calculate predicted value (excluding current sample itself)
                        HJi1 = Hi * pin_H_S1;
                        HJi2 = Hi * pin_H_S2;

                        if j <= Number1
                            P_yi(j) = (HJi1*YX1 + HJi2*YX2 - HJi1(j)*yi) / (1 - HJi1(j));
                        else
                            local_idx = j - Number1;
                            P_yi(j) = (HJi1*YX1 + HJi2*YX2 - HJi2(local_idx)*yi) / (1 - HJi2(local_idx));
                        end

                        % Calculate error
                        ri(j) = abs(yi - P_yi(j));
                    end

                    % Calculate RMSE
                    A = ri.^2;
                    b = sum(A);
                    current_rmse = sqrt(b / Number);

                    % Update and save optimal parameters
                    if current_rmse < best_rmse
                        best_rmse = current_rmse;
                        disp('Saving parameters');
                        % Save optimal parameters
                        save('optimal_MDGBL.mat', 'InputWeight', 'InputWeight1', 'wh', 'WF1', ...
                            'current_node1', 'current_node2', 'current_node3', 'current_lamda', 'current_gamma');
                        disp(['Minimum RMSE: ', num2str(best_rmse, '%.6f')]);
                    end
                end
            end
        end
    end
end

disp('[Parameter selection completed]');
end
% =========================================================================