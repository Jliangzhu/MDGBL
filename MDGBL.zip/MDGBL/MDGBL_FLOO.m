% =========================================================================
function [H_S1, H_S2, InputWeight, InputWeight1, wh, WF1] = MDGBL_FLOO(X_S1_feat, X_S2_feat, node1, node2, node3)
% -------------------------- 1. Initialization Configuration --------------------------
rng(0, 'twister');  

% Extract feature dimension and sample size
[num_S1, input_dim] = size(X_S1_feat);  
num_S2 = size(X_S2_feat, 1);            

% Initialize bias parameters
BiasofEnhanceNeurons = rand(1, node3);       

% Generate bias matrices
BiasMatrix_E1 = BiasofEnhanceNeurons(ones(num_S1, 1), :); 
BiasMatrix_E2 = BiasofEnhanceNeurons(ones(num_S2, 1), :); 

% -------------------------- 2. Calculation of Hidden Layer Output for Source Domain 1 --------------------------
feat_S1 = zeros(num_S1, node1 * node2);  
WF1 = cell(node2, 1);                  
InputWeight = cell(node2, 1);        

for i = 1:node2
    WF1{i} = 2 * rand(input_dim, node1) - 1;
    A1 = X_S1_feat * WF1{i};
    beta1 = sparse_bls(A1, X_S1_feat, 1e-3, 50)';
    feat_S1(:, node1*(i-1)+1 : node1*i) = X_S1_feat * beta1;
    InputWeight{i} = beta1;
end

wh = 2 * rand(node1 * node2, node3) - 1;  
enhance_S1 = feat_S1 * wh + BiasMatrix_E1;  
enhance_S1 = tansig(enhance_S1);  

H_S1 = [feat_S1, enhance_S1];

% -------------------------- 3. Calculation of Hidden Layer Output for Source Domain 2 --------------------------
% Reuse random weights from source domain 1
feat_S2 = zeros(num_S2, node1 * node2);  
InputWeight1 = cell(node2, 1);           

for i = 1:node2
    A2 = X_S2_feat * WF1{i};
    beta2 = sparse_bls(A2, X_S2_feat, 1e-3, 50)';
    feat_S2(:, node1*(i-1)+1 : node1*i) = X_S2_feat * beta2;
    InputWeight1{i} = beta2;
end

enhance_S2 = feat_S2 * wh + BiasMatrix_E2;  
enhance_S2 = tansig(enhance_S2);  

H_S2 = [feat_S2, enhance_S2];

end
% =========================================================================