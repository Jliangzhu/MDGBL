% =========================================================================
function [optimalWeights, bestPred] = MDGBL(...
    sourceDomain1, sourceDomain2, sourceDomainInc1, sourceDomainInc2, ...
    testData, activationFunc)

rng(0,'twister');
%% -------------------------- 1. Initialization and Parameter Settings -------------------------

paramFilePath = 'optimal_MDGBL.mat';
if exist(paramFilePath, 'file')
    paramData = load(paramFilePath);
else
    error('Parameter file %s not found! Please check the path.', paramFilePath);
end

% Verify if the parameter file contains all necessary fields
requiredParams = {'current_lamda', 'current_gamma', 'current_node1', ...
    'current_node2', 'current_node3', 'InputWeight', ...
    'InputWeight1', 'WF1', 'wh'};
for i = 1:length(requiredParams)
    if ~isfield(paramData, requiredParams{i})
        error('❌ Missing field in parameter file: %s. Please check the saving logic of the parameter optimization function!', requiredParams{i});
    end
end

% Extract parameters
regParam = paramData.current_lamda;       
incAdaptParam = paramData.current_gamma;    
hiddenNodeNum = paramData.current_node1;  
featureGroupNum = paramData.current_node2; 
enhanceNodeNum = paramData.current_node3;    
inputWeights = paramData.InputWeight;  
inputWeights2 = paramData.InputWeight1;       
enhanceWeights = paramData.wh;  

featureDim = size(sourceDomain1, 2) - 1;
assert(size(sourceDomain2, 2)-1 == featureDim, 'Feature dimensions of the two initial source domains must be consistent!');

%% -------------------------- 2. Data Preprocessing -------------------------
% Initial source domain 1
source1Labels = sourceDomain1(:, 1);
source1Features = sourceDomain1(:, 2:end);
n1 = size(source1Features, 1);

% Initial source domain 2
source2Labels = sourceDomain2(:, 1);
source2Features = sourceDomain2(:, 2:end);
n2 = size(source2Features, 1);

% Incremental source domain 1
inc1Labels = sourceDomainInc1(:, 1);
inc1Features = sourceDomainInc1(:, 2:end);
n_inc1 = size(inc1Features, 1);

% Incremental source domain 2
inc2Labels = sourceDomainInc2(:, 1);
inc2Features = sourceDomainInc2(:, 2:end);
n_inc2 = size(inc2Features, 1);

% Incremental source domain 2
allSources = {
    struct('X', source1Features, 'y', source1Labels), ...  % S1
    struct('X', source2Features, 'y', source2Labels), ...  % S2
    struct('X', inc1Features, 'y', inc1Labels), ...        % S3
    struct('X', inc2Features, 'y', inc2Labels)             % S4
    };

% Dimension check
assert(size(inc1Features, 2) == featureDim, 'Feature dimension of incremental source domain 1 does not match!');
assert(size(inc2Features, 2) == featureDim, 'Feature dimension of incremental source domain 2 does not match!');

%% -------------------------- 3. Feature Extraction and Mapping -------------------------
% Bias indices and bias values
biasInds1 = ones(n1, 1);
biasInds2 = ones(n2, 1);
biasIndsInc1 = ones(n_inc1, 1);
biasIndsInc2 = ones(n_inc2, 1);
enhanceBias = rand(1, enhanceNodeNum);

% 3.1 Feature mapping for initial source domain 1
source1Hidden = mapFeatures(source1Features, inputWeights, hiddenNodeNum, featureGroupNum);
source1Enhance = source1Hidden * enhanceWeights + enhanceBias(biasInds1, :);
[source1EnhanceAct, ~, ~] = applyActivationFunction(source1Enhance, [], [], activationFunc);
source1Total = [source1Hidden, source1EnhanceAct];

% 3.2 Feature mapping for initial source domain 2
source2Hidden = mapFeatures(source2Features, inputWeights2, hiddenNodeNum, featureGroupNum);
source2Enhance = source2Hidden * enhanceWeights + enhanceBias(biasInds2, :);
[source2EnhanceAct, ~, ~] = applyActivationFunction(source2Enhance, [], [], activationFunc);
source2Total = [source2Hidden, source2EnhanceAct];

% 3.3 Feature mapping for incremental source domain 1
inc1Hidden = mapFeatures(inc1Features, inputWeights2, hiddenNodeNum, featureGroupNum);
inc1Enhance = inc1Hidden * enhanceWeights + enhanceBias(biasIndsInc1, :);
[~, ~, inc1EnhanceAct] = applyActivationFunction([], [], inc1Enhance, activationFunc);
inc1Total = [inc1Hidden, inc1EnhanceAct];

% 3.3 Feature mapping for incremental source domain 2
inc2Hidden = mapFeatures(inc2Features, inputWeights2, hiddenNodeNum, featureGroupNum);
inc2Enhance = inc2Hidden * enhanceWeights + enhanceBias(biasIndsInc2, :);
[~, ~, inc2EnhanceAct] = applyActivationFunction([], [], inc2Enhance, activationFunc);
inc2Total = [inc2Hidden, inc2EnhanceAct];

allSourceTotals = {source1Total, source2Total, inc1Total, inc2Total};

%% -------------------------- 4. Initial Dual-Source Domain Model Construction -------------------------
infoMatrix = speye(size(source1Total, 2)) ...
    + regParam * (source1Total' * source1Total) ...
    + incAdaptParam * (source2Total' * source2Total);

initialWeights = pinv(infoMatrix) * ( ...
    regParam * (source1Total' * source1Labels) + ...
    incAdaptParam * (source2Total' * source2Labels) ...
    );

%% -------------------------- 5. Incremental  Transfer---------------------------
persistent prevWeights prevInfoInv;
prevWeights = initialWeights;
prevInfoInv = pinv(infoMatrix);

% 5.1 First source domain increment
inc1Feat = inc1Total;
inc1Lbl = inc1Labels;

residual1 = inc1Lbl - inc1Feat * prevWeights;

updateMat1 = speye(size(inc1Feat, 1)) + inc1Feat * prevInfoInv * inc1Feat';
updateMat1Inv = pinv(updateMat1);
weightDelta1 = prevInfoInv * inc1Feat' * updateMat1Inv * residual1;
weightsAfterInc1 = prevWeights + weightDelta1;  

prevInfoInv = prevInfoInv - prevInfoInv * inc1Feat' * updateMat1Inv * inc1Feat * prevInfoInv;

% 5.2 Second source domain increment
inc2Feat = inc2Total;
inc2Lbl = inc2Labels;

residual2 = inc2Lbl - inc2Feat * weightsAfterInc1;

updateMat2 = speye(size(inc2Feat, 1)) + inc2Feat * prevInfoInv * inc2Feat';
updateMat2Inv = pinv(updateMat2);
weightDelta2 = prevInfoInv * inc2Feat' * updateMat2Inv * residual2;
weightsAfterInc2 = weightsAfterInc1 + weightDelta2;  

%% -------------------------- 6. Multi-Dimensional Evaluation and Optimal Weight Selection -------------------------
candidateWeights = {initialWeights, weightsAfterInc1, weightsAfterInc2};
weightNames = {'Initial dual-source domain weights', 'Weights after first increment', 'Weights after second increment'};
numWeights = length(candidateWeights);
numSources = length(allSources);  

% Cross-source domain fitting ability
sourceScores = zeros(1, numWeights);
validationPairs = [2; 3; 3];  % Validation source domain index for each weight

for k = 1:numWeights
    valIdx = validationPairs(k);
    X_val = allSourceTotals{valIdx};
    y_val = allSources{valIdx}.y;
    pred_val = X_val * candidateWeights{k};
    rmse_val = sqrt(mse(y_val - pred_val));
    sourceScores(k) = 1 / (1 + rmse_val);  
end

% Cross-source domain generalization consistency
genScores = zeros(1, numWeights);
for k = 1:numWeights
    rmseAll = 0;  
    for s = 1:numSources
        X_s = allSourceTotals{s};
        y_s = allSources{s}.y;
        pred_s = X_s * candidateWeights{k};
        rmseAll = rmseAll + sqrt(mse(y_s - pred_s));
    end
    avgRmse = rmseAll / numSources;
    genScores(k) = 1 / (1 + avgRmse);  
end

% % -------------------------- Core: Scale genScores globally to maintain dimension consistency--------------------------
% targetMin = 0.1;  
% 
% maxGen = max(genScores);
% 
% if maxGen == 0
%     scaledGen = genScores;
%     scaleFactor = 1;
% else
%     % maxGen * 10^exponent ≥ targetMin
%     exponent = ceil(log10(targetMin / maxGen));  
%     exponent = max(exponent, 0);  
%     scaleFactor = 10^exponent;  
% 
%     scaledGen = genScores * scaleFactor;  
% end
% 
% genScores = scaledGen;
% 
% % Output scaled results
% disp(['Scaled genScores (max ≥ ', num2str(targetMin), '):']);
% disp(genScores);
% disp(['Scaling factor (10^', num2str(exponent), '): ', num2str(scaleFactor)]);


% Consistency of source domain prediction distribution
consScores = zeros(1, numWeights);
for k = 1:numWeights
    preds = cell(numSources, 1);
    for s = 1:numSources
        preds{s} = allSourceTotals{s} * candidateWeights{k};
    end

    divList = []; 
    for i = 1:numSources-1
        for j = i+1:numSources
            pred_i_norm = (preds{i} - median(preds{i})) / (iqr(preds{i}) + eps);
            pred_j_norm = (preds{j} - median(preds{j})) / (iqr(preds{j}) + eps);

            minLen = min(length(pred_i_norm), length(pred_j_norm));
            pred_i_align = pred_i_norm(1:minLen);
            pred_j_align = pred_j_norm(1:minLen);

            rmse_div = sqrt(mse(pred_i_align - pred_j_align));
            divList = [divList, rmse_div];  
        end
    end

    if ~isempty(divList)
        avgDiv = median(divList);  
    else
        avgDiv = 0;  
    end

    consScores(k) = 1 / (1 + avgDiv);  
end

% Comprehensive score (weight coefficients can be adjusted)
totalScores = 0.3*sourceScores + 0.35*genScores + 0.35*consScores;

% Select optimal weights
[~, optimalIdx] = max(totalScores);
optimalWeights = candidateWeights{optimalIdx};

disp(['Optimal weights: ', weightNames{optimalIdx}]);

%% -------------------------- 7. Generalization Prediction -------------------------
testFeatures = testData(:, 2:end);
testHidden = mapFeatures(testFeatures, inputWeights2, hiddenNodeNum, featureGroupNum);
testEnhance = testHidden * enhanceWeights + enhanceBias(ones(size(testFeatures,1),1), :);
[~, ~, testEnhanceAct] = applyActivationFunction([], [], testEnhance, activationFunc);
testTotal = [testHidden, testEnhanceAct];

bestPred = testTotal * optimalWeights;

%% -------------------------- Auxiliary Functions -------------------------
    function hidden = mapFeatures(features, weights, hiddenNodeNum, featureGroupNum)
        nSample = size(features, 1);
        hidden = zeros(nSample, hiddenNodeNum * featureGroupNum);
        for i = 1:featureGroupNum
            groupFeat = features * weights{i};
            hidden(:, hiddenNodeNum*(i-1)+1 : hiddenNodeNum*i) = groupFeat;
        end
    end

    function [feat1, feat2, feat3] = applyActivationFunction(feat1, feat2, feat3, funcType)
        funcType = lower(funcType);
        switch funcType
            case 'tansig'
                if ~isempty(feat1), feat1 = tanh(feat1); end
                if ~isempty(feat2), feat2 = tanh(feat2); end
                if ~isempty(feat3), feat3 = tanh(feat3); end
            case {'sig', 'sigmoid'}
                if ~isempty(feat1), feat1 = 1 ./ (1 + exp(-feat1)); end
                if ~isempty(feat2), feat2 = 1 ./ (1 + exp(-feat2)); end
                if ~isempty(feat3), feat3 = 1 ./ (1 + exp(-feat3)); end
            case 'radbas'
                if ~isempty(feat1), feat1 = exp(-feat1.^2); end
                if ~isempty(feat2), feat2 = exp(-feat2.^2); end
                if ~isempty(feat3), feat3 = exp(-feat3.^2); end
            otherwise
                warning('Unrecognized activation function, using default tansig');
                if ~isempty(feat1), feat1 = tanh(feat1); end
                if ~isempty(feat2), feat2 = tanh(feat2); end
                if ~isempty(feat3), feat3 = tanh(feat3); end
        end
    end
end
% =========================================================================