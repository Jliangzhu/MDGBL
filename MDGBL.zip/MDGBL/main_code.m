% =========================================================================
clear all;
clc;
load Source1_train_y;
load Source1_train_x;
load Source2_train_y;
load Source2_train_x;
load Source3_train_y;
load Source3_train_x;
load Source4_train_y;
load Source4_train_x;
load Target_test_x;

%%
source1_train_y=zscore(Source1_train_y);
source1_train_x=zscore(Source1_train_x);
source2_train_y=zscore(Source2_train_y);
source2_train_x=zscore(Source2_train_x);
source3_train_y=zscore(Source3_train_y);
source3_train_x=zscore(Source3_train_x);
source4_train_y=zscore(Source4_train_y);
source4_train_x=zscore(Source4_train_x);

source1_train=[source1_train_y,source1_train_x];
source2_train=[source2_train_y,source2_train_x];
source3_train=[source3_train_y,source3_train_x];
source4_train=[source4_train_y,source4_train_x];

target_test_x = zscore(Target_test_x);
target_test_y = zeros(size(Target_test_x, 1), 1); 

target_test=[target_test_y,target_test_x];

% MDGBL
best = MDGBL_FLOO_Node(source1_train, source2_train,10,40,10,1,5,1,10,100,10);
[optimalWeights, bestPred] = MDGBL(source1_train, source2_train, source3_train, source4_train, target_test,  'tansig');
TY_MDGBL = bestPred;  
% =========================================================================
